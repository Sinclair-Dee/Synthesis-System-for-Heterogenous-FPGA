#ifndef __global_H
#define __global_H

#ifdef __cplusplus
extern "C"{
#endif

	extern const char* base;
	extern char user_in_file_path_name[];
	extern char user_out_file_path_name[];
	extern const char*edif_blif;
	extern char syn_message[];

#ifdef __cplusplus
};
#endif

#define __VERIFICATION__

//extern const char* base;
//extern char* userInFilePathName;
//extern char* userOutFilePathName;
//extern const char*edif_blif;
//extern char* synMessage;

#endif